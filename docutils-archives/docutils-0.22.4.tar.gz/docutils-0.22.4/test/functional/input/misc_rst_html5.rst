============================
Additional tests with HTML 5
============================

.. contents::

.. include:: data/section_titles.rst
.. include:: data/embed_images.rst
.. include:: data/video.rst
