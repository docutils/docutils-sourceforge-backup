PEP: 100
Title: Test PEP
Version: 42
Last-Modified: A long time ago.
Author: John Doe <john@example.org>
Discussions-To: <devnull@example.org>
Status: Draft
Type: Standards Track
Content-Type: text/x-rst
Created: 01-Jun-2001
Post-History: 13-Jun-2001


Abstract
========

This is just a test [#]_.  See the `PEP repository`_ for the real
thing.

.. _PEP repository: http://www.python.org/peps/


Copyright
=========

This document has been placed in the public domain.


References and Footnotes
========================

.. [#] PEP editors: peps@python.org
