[general]
# overwrite `error_encoding` but leave `error_encoding_error_handler` unchanged
error_encoding: latin1
