.. Minimal menu bar for inclusion in documentation sources
   in ``docutils/docs/*/`` sub-sub-diretories.

   Attention: this is not a standalone document.

.. header::
   Docutils__ | Overview__ | About__ | Users__ | Reference__ | Developers__

   __ https://docutils.sourceforge.io

   __ ../../index.html
   __ ../../index.html#project-fundamentals
   __ ../../index.html#user
   __ ../../index.html#ref
   __ ../../index.html#howto
