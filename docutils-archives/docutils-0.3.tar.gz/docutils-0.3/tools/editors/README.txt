======================================
 Editor Support for reStructuredText_
======================================

:Date: $Date: 2003/02/03 19:30:37 $

The files in this directory contain support code for reStructuredText
editing for the following editors:

* `Emacs <emacs>`__

.. _reStructuredText: http://docutils.sf.net/rst.html
