======================================
 Editor Support for reStructuredText_
======================================

:Date: $Date: 2004/06/14 14:31:01 $

The files in this directory contain support code for reStructuredText
editing for the following editors:

* `Emacs <emacs>`__

External links:

* `reStructuredText syntax highlighting mode for vim
  <http://www.vim.org/scripts/script.php?script_id=973>`__

Additions are welcome.

.. _reStructuredText: http://docutils.sf.net/rst.html
