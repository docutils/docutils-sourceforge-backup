=========
Footnotes
=========

manually numbered [1]_ and referenced twice [1]_ .

.. [1] A footnote contains body elements, consistently indented by at
   least 1 space.
