.. -*- encoding: latin2 -*-

�koda
