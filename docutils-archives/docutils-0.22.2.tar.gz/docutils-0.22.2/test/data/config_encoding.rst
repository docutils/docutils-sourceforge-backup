[general]
# set `error_encoding` and `error_encoding_error_handler`
error_encoding: ascii:strict
