# Test config file (new format)

[general]

output-encoding-error-handler: namereplace


[html4css1 writer]
# section also used by the "pep_html" writer

footnote-references: superscript
stylesheet-path: test.css

# general settings or settings from other components may be used,
# e.g., only set generator to False, if this section is set active
generator: no
