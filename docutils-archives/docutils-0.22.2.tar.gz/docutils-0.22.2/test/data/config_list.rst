[general]
expose_internals: a
strip-classes: spam
strip-elements-with-classes: sugar, flour
smartquotes-locales: de: «»‹›

[html4css1 writer]
expose_internals: b:c:d
strip-classes: pan,
               fun,
strip-elements-with-classes: milk

[pep_html writer]
expose_internals: e
strip-classes: parrot
strip-elements-with-classes: safran
