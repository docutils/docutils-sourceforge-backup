.. Minimal menu bar for inclusion in enhancement proposal sources
   in ``docutils/docs/eps/``.

   Attention: this is not a standalone document.

.. header::
   Docutils__ | Overview__ | `Enhancement Proposals`__

   __ https://docutils.sourceforge.io

   __ ../index.html
   __ index.html
