=================
Header and Footer
=================

.. header:: head in the clouds

.. footer:: feets getting wet

... only *boldness* can deliver from fear. And if the risk is not taken, the
meaning of life is somehow violated, and the whole future is condemned to
hopeless staleness.

  -- (Carl Jung, Symbols of Transformation)
