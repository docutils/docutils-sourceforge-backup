:Author: Foo Fred
:Organization: Food Foomatics & Friends
:Contact: foo@food.example.info
:Address: Fox St 13
          Foowood
:Author: Bar Barney
:Organization: Bar-BQ Bar
:Contact: 1-800-BARBQBAR
:Address: Barbara St 16
          South Barwell
