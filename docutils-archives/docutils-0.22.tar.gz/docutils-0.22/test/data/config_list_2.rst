[general]
expose_internals: f
strip-classes: ham,  eggs
strip-elements-with-classes: eggs,salt
# `stylesheet` overrides earlier `stylesheet` and `stylesheet_path` settings
stylesheet: style2.css,
            style3.css
smartquotes-locales: nl: „”’’,
                     cs: »«›‹

[html4css1 writer]
smartquotes-locales: fr: « : »:‹ : ›
