# Test reporting of config file syntax error

[general]

strip-classes: myclass, No*class
