In ../includes/include9.rst.

.. include:: ../test_directives/include2.rst
