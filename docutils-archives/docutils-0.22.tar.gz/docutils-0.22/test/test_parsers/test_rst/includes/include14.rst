Paragraph starting in line 1.
With *inline* element in line 2.

  Block quote in line 4

  -- attribution
     in line 6

* bullet list in line 9
* second item in line 10

1. enumerated list in line 12

.. admonition:: line 14

   Generic admonition text in line 16

term on line 18
   definition in line 19
