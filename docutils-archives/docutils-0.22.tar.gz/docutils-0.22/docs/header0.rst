.. Minimal menu bar for inclusion in documentation sources
   in the ``docutils/`` parent diretory.

   Attention: this is not a standalone document.

.. header::
   Docutils__ | Overview__ | About__ | Users__ | Reference__ | Developers__

   __ https://docutils.sourceforge.io
   __ docs/index.html
   __ docs/index.html#project-fundamentals
   __ docs/index.html#user
   __ docs/index.html#ref
   __ docs/index.html#howto
