#! /usr/bin/env python
# $Id: model.py,v 1.1 2001/05/22 00:26:33 David_Goodger Exp $
# by David Goodger (dgoodger@bigfoot.com)


class Parser:

    def __init__(self, inputstring, errors='warn', language='en'):
        """
        Initialize the Parser instance.
        """
        pass

    def parse(self):
        """Return a DOM tree, the parsed input string."""
        pass
