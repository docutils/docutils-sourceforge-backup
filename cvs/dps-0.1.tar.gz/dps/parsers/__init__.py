#! /usr/bin/env python
# $Id: __init__.py,v 1.1 2001/05/22 00:26:14 David_Goodger Exp $
# by David Goodger (dgoodger@bigfoot.com)
