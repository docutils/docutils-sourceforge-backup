#! /usr/bin/env python
# $Id: __init__.py,v 1.1 2001/05/22 00:28:43 David_Goodger Exp $
# by David Goodger (dgoodger@bigfoot.com)

from dps.parsers import model


class Parser(model.Parser):
    pass
