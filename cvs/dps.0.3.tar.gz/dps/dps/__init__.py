#! /usr/bin/env python
# $Id: __init__.py,v 1.1.1.1 2001/07/22 22:35:43 goodger Exp $
# by David Goodger
